function R = rotmat2d(theta)
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];
end