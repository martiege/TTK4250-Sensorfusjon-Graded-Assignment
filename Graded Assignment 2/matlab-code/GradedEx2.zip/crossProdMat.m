function S = crossProdMat(n)
S = %
end