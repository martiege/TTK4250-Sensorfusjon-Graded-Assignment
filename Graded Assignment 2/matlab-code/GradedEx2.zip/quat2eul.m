function eul = quat2eul(q)
qSquared = q.^2;

phi = %
theta = %
psi = %

eul = [phi; theta; psi];
end